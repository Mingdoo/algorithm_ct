# 코드 부연설명

##### 1. 

elo rating system을 사용한 랭킹 시스템을 구현했습니다.



초기조건 : 모든 사람의 레이팅이 1500으로 고정된다.

레이팅 포인트에 따라 승률을 예측할 수 있는 모델을 만든다.

![image-20210925183852717](README.assets/image-20210925183852717.png)

출처 : https://ko.wikipedia.org/wiki/%EC%97%98%EB%A1%9C_%ED%8F%89%EC%A0%90_%EC%8B%9C%EC%8A%A4%ED%85%9C

대결조건 : 이긴 사람은 레이팅 시스템에 맞게 승점을 획득하며, 진 사람은 레이팅 시스템에 맞게 승점을 잃는다.

![image-20210925183942706](README.assets/image-20210925183942706.png)



위 조건에 맞는 적절한 K, 그리고 모든 사람이 같은 레이팅에서 시작할 때는 같은 K값으로 적용되지만, 판수가 늘어날수록 높은 K값은 적절하지 않아 K값을 계속 낮추는 방법으로 구현하였음.

```python
if res['time'] % 54 == 0:
    K *= 0.97
```



##### 2. 

문제 2에서 적용된 어뷰징 유저는 자신보다 약한 상대에게 져주는 나쁜 고약한 버릇이 있다.!!

이를 잡기 위해서는, elo 레이팅 시스템이 적용된 승점대로의 승률이 80% 이상인데 지는 경우에, 가산점을 부여하여 K값에 추가된 abuse_K를 가중하여 elo 랭킹에 적용되도록 구현하였다.

``` python
if E_w > 0.8 and abuse_point[winner] > abuse_K:
    abuse_point[winner] -= abuse_K / 2
if E_l > 0.8:
    abuse_point[loser] += abuse_K
grade[winner]['grade'] += (K + abuse_point[winner]) * (1 - E_w)
grade[loser]['grade'] += -((K - abuse_point[loser]) * E_l)
```



만약 억울하게 어뷰징 유저로 찍힌 유저들은 다시 승률이 0.8 이상일때 이기면 어뷰징 포인트를 깎는 방법으로 구현하였다.